package com.example.fast_stock.bean;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.fast_stock.model.Produto;
import com.example.fast_stock.repository.ProdutoRepository;

import jakarta.faces.view.ViewScoped;
import java.io.Serializable;

@Component
@ViewScoped
public class ProdutoBean implements Serializable {
    private static final long serialVersionUID = 1L;

    @Autowired
    private ProdutoRepository produtoRepository;

    private List<Produto> produtos;

    public List<Produto> getProdutos() {
        if (produtos == null) {
            produtos = produtoRepository.findAll();
        }
        return produtos;
    }
}
