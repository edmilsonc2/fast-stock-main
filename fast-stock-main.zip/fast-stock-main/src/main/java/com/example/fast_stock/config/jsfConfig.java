package com.example.fast_stock.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.SessionScope;

import jakarta.faces.annotation.FacesConfig;

@Configuration
@FacesConfig
public class jsfConfig { // Nome da classe com "J" maiúsculo

    @Bean
    @SessionScope
    public String jsfConfigBean() {
        return "jsfConfig";
    }
}

