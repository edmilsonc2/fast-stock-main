package com.example.fast_stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
